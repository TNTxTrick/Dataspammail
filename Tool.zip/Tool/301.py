ngay = str(__import__('time').strftime("%d"))
thang = str(__import__('time').strftime("%m"))
nam = str(__import__('time').strftime("%Y"))
class Key:
    def keyfree():
        return __import__('hashlib').md5(f"NgTuw-{ngay}{thang}{nam}{ip}{pyver}".encode()).hexdigest()
    def keyvip():
        return ["keyvipbytoolngtuw", "ngtuwdz"]
if __import__('os').path.exists("NgTuwKey.json"):
    code = __import__('json').loads(open("NgTuwKey.json", "r").read())
    inp = code['key']
    mode = code['mode']
    key = Key.keyfree() if mode == 1 else Key.keyvip()
    if inp in key:
        pass
    else:
        __import__('sys').exit()
else:
    __import__('sys').exit()



import smtplib, sys
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import concurrent.futures
import os

# Màu sắc hiển thị
mo_ngoac = "\033[1m[\x1b[1;38;2;173;255;47m"  
dong_ngoac = "\033[0m\033[1m]"  
mo_ngoac_do = "\033[1m[\033[1;31m"  
xanhchuoi = "\x1b[1;38;2;173;255;47m"  
xanhla = "\033[1;32m"  
do = "\033[1;31m"  
trangdam = "\x1b[1;38;2;233;233;233m"  
resetmau = "\033[0m\33[1m" 
xanhduongnhat = "\x1b[1;38;2;135;206;250m" 
hongnhat = "\x1b[1;38;2;255;182;193m"  
cam = "\x1b[1;38;2;255;165;0m" 

def send_email(mail, matkhau, mail_spam, tieude, noidungs, tennguoigui):
    try:
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(mail, matkhau)
        for noidung in noidungs:
            msg = MIMEMultipart()
            msg['From'] = f"{tennguoigui} <{mail}>"
            msg['To'] = mail_spam
            msg['Subject'] = tieude
            msg.attach(MIMEText(noidung, 'plain'))
            text = msg.as_string()
            server.sendmail(mail, mail_spam, text)
            print(f"{mo_ngoac}T-TOOL{dong_ngoac} | Nội Dung: {noidung} | Từ: {mail} | Đến: {mail_spam}")        
        server.quit()
    except Exception as e:
        print(f"{mo_ngoac_do}T-TOOL{dong_ngoac} | Từ: {mail} | Đến: {mail_spam}\nLỗi: {e}")

def read_file(file_path):
    if not os.path.exists(file_path):
        print(f"{mo_ngoac_do}T-TOOL{dong_ngoac} | Không tìm thấy file: {file_path}")
        sys.exit(1)   
    with open(file_path, 'r', encoding='utf-8') as file:
        return [line.strip() for line in file.readlines()]

file_email_pass = input(f' \033[1;37;40m➤ \033[1;31;40m[\033[1;33;40m«\033[1;37;40m/\033[1;33;40m»\033[1;31;40m] \033[1;37;40m> {trangdam}Nhập Tên File Chứa Email SMTP (Định Dạng Email:Pass): ')
ten_file_noidung = input(f' \033[1;37;40m➤ \033[1;31;40m[\033[1;33;40m«\033[1;37;40m/\033[1;33;40m»\033[1;31;40m] \033[1;37;40m> {trangdam}Nhập Tên File Chứa Nội Dung: ')
ten_file_email = input(f' \033[1;37;40m➤ \033[1;31;40m[\033[1;33;40m«\033[1;37;40m/\033[1;33;40m»\033[1;31;40m] \033[1;37;40m> {trangdam}Nhập Tên File Chứa Danh Sách Email Spam: ')
tennguoigui = input(f' \033[1;37;40m➤ \033[1;31;40m[\033[1;33;40m«\033[1;37;40m/\033[1;33;40m»\033[1;31;40m] \033[1;37;40m> {trangdam}Nhập Username Của Bạn: ')
tieude = input(f' \033[1;37;40m➤ \033[1;31;40m[\033[1;33;40m«\033[1;37;40m/\033[1;33;40m»\033[1;31;40m] \033[1;37;40m> {trangdam} Nhập Tiêu Đề: ')
so_luong_luong = int(input(f' \033[1;37;40m➤ \033[1;31;40m[\033[1;33;40m«\033[1;37;40m/\033[1;33;40m»\033[1;31;40m] \033[1;37;40m> {trangdam}Nhập Số Luồng: '))
email_pass_list = read_file(file_email_pass)
noidungs = read_file(ten_file_noidung)
mail_spams = read_file(ten_file_email)
with concurrent.futures.ThreadPoolExecutor(max_workers=so_luong_luong) as executor:
    futures = []
    for mail_spam in mail_spams:
        for email_pass in email_pass_list:
            mail, matkhau = email_pass.split(':', 1)
            futures.append(executor.submit(send_email, mail, matkhau, mail_spam, tieude, noidungs, tennguoigui))
    concurrent.futures.wait(futures)
print(" \033[1;37;40m➤ \033[1;31;40m[\033[1;33;40m«\033[1;37;40m/\033[1;33;40m»\033[1;31;40m] \033[1;37;40m> Đã Gửi Thành Công Tất Cả Email Trong Danh Sách!")
sys.exit()