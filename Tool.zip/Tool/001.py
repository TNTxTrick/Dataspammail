#/c/ea991b37-e128-4c96-bfa6-54b7e9abf68c

ngay = str(__import__('time').strftime("%d"))
thang = str(__import__('time').strftime("%m"))
nam = str(__import__('time').strftime("%Y"))
class Key:
    def keyfree():
        return __import__('hashlib').md5(f"NgTuw-{ngay}{thang}{nam}{ip}{pyver}".encode()).hexdigest()
    def keyvip():
        return ["keyvipbytoolngtuw", "ngtuwdz"]
if __import__('os').path.exists("NgTuwKey.json"):
    code = __import__('json').loads(open("NgTuwKey.json", "r").read())
    inp = code['key']
    mode = code['mode']
    key = Key.keyfree() if mode == 1 else Key.keyvip()
    if inp in key:
        pass
    else:
        __import__('sys').exit()
else:
    __import__('sys').exit()


import hashlib
import random
import requests
import time
from datetime import datetime
import json
import sys
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Constants for formatting
MO_NGOAC_XANH_CHUOI = "\x1b[1;38;2;173;255;47m"
MO_NGOAC_XANH_LA = "\033[1;32m"
DO = "\033[1;31m"
THANH = "\x1b[1;38;2;135;206;250m" + '═' * 60 + "\033[0m"

APP = {
    'api_key': '882a8490361da98702bf97a021ddc14d',
    'secret': '62f8ce9f74b12f84c123cc23437a4a32',
    'key': ['NgTuwDz', 'SangBangTatCa']
}

EMAIL_PREFIX = [
    'gmail.com', 'hotmail.com', 'yahoo.com', 'live.com', 'rocket.com', 'outlook.com'
]

def generate_random_name():
    first_names = ['JAMES', 'JOHN', 'ROBERT', 'MICHAEL', 'WILLIAM', 'DAVID']
    last_names = ['SMITH', 'JOHNSON', 'WILLIAMS', 'BROWN', 'JONES', 'MILLER']
    middle_names = ['Alexander', 'Anthony', 'Charles', 'Dash', 'David', 'Edward']
    first_name = random.choice(first_names)
    last_name = random.choice(last_names)
    middle_name = random.choice(middle_names)
    return f"{first_name} {middle_name} {last_name}"

def generate_random_email(full_name):
    md5_hash = hashlib.md5((str(time.time()) + datetime.strftime(datetime.now(), '%Y%m%d')).encode()).hexdigest()
    return f"{full_name.replace(' ', '').lower()}{md5_hash[:6]}@{random.choice(EMAIL_PREFIX)}"

def generate_random_birthday():
    start_date = datetime.strptime('1980-01-01', '%Y-%m-%d')
    end_date = datetime.strptime('1995-12-30', '%Y-%m-%d')
    timestamp = random.randint(int(time.mktime(start_date.timetuple())), int(time.mktime(end_date.timetuple())))
    return datetime.strftime(datetime.fromtimestamp(timestamp), '%Y-%m-%d')

def generate_request_data(full_name, email, password, birthday, gender):
    md5_time = hashlib.md5(str(time.time()).encode()).hexdigest()
    hash_ = f"{md5_time[:8]}-{md5_time[8:12]}-{md5_time[12:16]}-{md5_time[16:20]}-{md5_time[20:32]}"
    req = {
        'api_key': APP['api_key'],
        'attempt_login': True,
        'birthday': birthday,
        'client_country_code': 'EN',
        'fb_api_caller_class': 'com.facebook.registration.protocol.RegisterAccountMethod',
        'fb_api_req_friendly_name': 'registerAccount',
        'firstname': full_name.split()[0],
        'format': 'json',
        'gender': gender,
        'lastname': full_name.split()[-1],
        'email': email,
        'locale': 'en_US',
        'method': 'user.register',
        'password': password,
        'reg_instance': hash_,
        'return_multiple_errors': True
    }
    sig = ''.join([f'{k}={v}' for k, v in sorted(req.items())])
    sig = hashlib.md5((sig + APP['secret']).encode()).hexdigest()
    req['sig'] = sig
    return req

def create_account():
    full_name = generate_random_name()
    email = generate_random_email(full_name)
    birthday = generate_random_birthday()
    password = f'ChanHungCoder{random.randint(0, 9999999)}?#@'
    gender = 'M' if random.randint(0, 10) > 5 else 'F'
    req = generate_request_data(full_name, email, password, birthday, gender)
    api_url = 'https://b-api.facebook.com/method/user.register'
    response = requests.post(api_url, data=req, headers={
        'User-Agent': '[FBAN/FB4A;FBAV/35.0.0.48.273;FBDM/{density=1.33125,width=800,height=1205};FBLC/en_US;FBCR/;FBPN/com.facebook.katana;FBDV/Nexus 7;FBSV/4.1.1;FBBK/0;]'
    }, verify=False)
    reg_json = response.json()
    uid = reg_json.get('session_info', {}).get('uid')
    access_token = reg_json.get('session_info', {}).get('access_token')
    error_code = reg_json.get('error_code')
    error_msg = reg_json.get('error_msg')
    if uid and access_token:
        return {
            'birthday': birthday,
            'full_name': full_name,
            'email': email,
            'password': password,
            'uid': uid,
            'token': access_token
        }
    else:
        return {'error_code': error_code, 'error_msg': error_msg}

def main():
    while True:
        try:
            account_count = int(input(f" \033[1;37;40m➤ \033[1;31;40m[\033[1;33;40m«\033[1;37;40m/\033[1;33;40m»\033[1;31;40m] \033[1;37;40m> {DO}Nhập Số Lượng Acc Muốn Reg: "))
            if account_count > 0:
                break
            else:
                print(f"{DO}! Số Lượng Acc Phải Lớn Hơn 0. Vui Lòng Nhập lại!")
        except ValueError:
            print(f"{DO}! Nội Dung Nhập Không Hợp Lệ!")
    while True:
        file_name = input(f" \033[1;37;40m➤ \033[1;31;40m[\033[1;33;40m«\033[1;37;40m/\033[1;33;40m»\033[1;31;40m] \033[1;37;40m> {DO}Nhập Tên File Lưu Thông Tin: ")
        if file_name.strip():
            if not file_name.endswith(".txt"):
                file_name += ".txt"
            break
        else:
            print(f"{DO}! Tên File Không Được Để Trống. Vui Lòng Nhập Lại!")
    while True:
        try:
            delay = int(input(f" \033[1;37;40m➤ \033[1;31;40m[\033[1;33;40m«\033[1;37;40m/\033[1;33;40m»\033[1;31;40m] \033[1;37;40m> {DO}Nhập Thời Gian Delay (Trên 180 Giây): "))
            if delay > 10:
                break
            else:
                print(f"{DO}! Delay Phải Lớn Hơn 179 Giây. Vui Lòng Nhập Lại!")
        except ValueError:
            print(f"{DO}! Nội Dung Nhập Không Hợp Lệ!")
    for _ in range(account_count):
        account = create_account()
        if 'uid' in account:
            with open(file_name, "a") as file:
                file.write(f"{account['birthday']}:{account['full_name']}:{account['email']}:{account['password']}:{account['uid']}:{account['token']}\n")
            print(f"Thông tin tài khoản đã được lưu vào file: {file_name}")
        else:
            print(f"Error Code: {account['error_code']}")
            print(f"Error Message: {account['error_msg']}")
        time.sleep(delay)
    print(f"{THANH} Hoàn Thành! Tất Cả Tài Khoản Đã Được Tạo Và Lưu Vào File: {file_name}")
if __name__ == "__main__":
    main()