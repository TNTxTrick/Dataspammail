ngay = str(__import__('time').strftime("%d"))
thang = str(__import__('time').strftime("%m"))
nam = str(__import__('time').strftime("%Y"))
class Key:
    def keyfree():
        return __import__('hashlib').md5(f"NgTuw-{ngay}{thang}{nam}{ip}{pyver}".encode()).hexdigest()
    def keyvip():
        return ["keyvipbytoolngtuw", "ngtuwdz"]
if __import__('os').path.exists("NgTuwKey.json"):
    code = __import__('json').loads(open("NgTuwKey.json", "r").read())
    inp = code['key']
    mode = code['mode']
    key = Key.keyfree() if mode == 1 else Key.keyvip()
    if inp in key:
        pass
    else:
        __import__('sys').exit()
else:
    __import__('sys').exit()


import requests, json, os, sys
from threading import Thread
import threading
from datetime import datetime
from time import strftime
from time import sleep
import random
from pystyle import Colors, Colorate
camxuc=[]
dem=0


class Facebook:
	def __init__(self,cookie):
		self.cookie = cookie
		self.headers = {
			'authority': 'mbasic.facebook.com',
			'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
			'accept-language': 'vi,en;q=0.9,vi-VN;q=0.8,fr-FR;q=0.7,fr;q=0.6,en-US;q=0.5',
			'cache-control': 'max-age=0',
			'cookie': cookie,
			'origin': 'https://www.facebook.com',
			'referer': 'https://www.facebook.com',
			'sec-ch-ua': '"Google Chrome";v="107", "Chromium";v="107", "Not=A?Brand";v="24"',
			'sec-ch-ua-mobile': '?0',
			'sec-ch-ua-platform': '"Windows"',
			'sec-fetch-dest': 'document',
			'sec-fetch-mode': 'navigate',
			'sec-fetch-site': 'none',
			'sec-fetch-user': '?1',
			'upgrade-insecure-requests': '1',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36',
			}
	def get_thongtin(self):
		try:
			url=requests.get('https://mbasic.facebook.com/profile.php',headers=self.headers).url
			home = requests.get(url,headers=self.headers).text
			self.fb_dtsg = home.split('<input type="hidden" name="fb_dtsg" value="')[1].split('"')[0]
			self.jazoest = home.split('<input type="hidden" name="jazoest" value="')[1].split('"')[0]
			ten = home.split('<title>')[1].split('</title>')[0]
			self.user_id = cookie.split('c_user=')[1].split(';')[0]
			print(Colorate.Horizontal(Colors.green_to_white, f'Name Facebook: {ten} | ID: {self.user_id} '))
			sys.stdout.flush()
		except:
			print(Colorate.Horizontal(Colors.green_to_white, 'Error GET Info Pls ..'))
			return 0
	def get_pro5(self):
		headers={
           	     'authority': 'www.facebook.com',
            	    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
          	      'accept-language': 'vi',
       	         'cookie': self.cookie,
           	     'sec-ch-prefers-color-scheme': 'light',
            	    'sec-ch-ua': '"Chromium";v="106", "Google Chrome";v="106", "Not;A=Brand";v="99"',
            	    'sec-ch-ua-mobile': '?0',
          	      'sec-ch-ua-platform': '"Windows"',
          	      'sec-fetch-dest': 'document',
           	     'sec-fetch-mode': 'navigate',
           	     'sec-fetch-site': 'none',
           	     'sec-fetch-user': '?1',
             	   'upgrade-insecure-requests': '1',
           	     'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36',
            	    'viewport-width': '1366',
          	 	 }
		data ={
					'av':self.user_id,
					'fb_dtsg':self.fb_dtsg,
					'jazoest':self.jazoest,
					'fb_api_caller_class':'RelayModern',
					'fb_api_req_friendly_name':'CometSettingsDropdownListQuery',
					'variables':'{"fetchTestUserProfileListCell":false,"includeHorizBadging":false,"inProfileSwitcherEntry":false,"inSimpleHeaderEntry":true,"scale":2}',
					'server_timestamps':'true',
					'doc_id':'8179507702122101',
				}
		try:
			a=requests.post('https://www.facebook.com/api/graphql/', headers=headers,data=data).json()
			get = a['data']['viewer']['actor']['profile_switcher_eligible_profiles']
			tong = get['count']
			data_pro5 = get['nodes']
			print(Colorate.Horizontal(Colors.green_to_white, f'| {tong} Page Profile'))
			return data_pro5
		except:
			print(Colorate.Horizontal(Colors.green_to_white, '\nProfile Page Not Found!'))
			exit()

	def View(self,story_url,id_page,name):
		cookie = self.cookie
		ck_pro5 = 'sb={}; datr={}; c_user={}; wd={}; xs={}; fr={}; i_user={};'.format(cookie.split('sb=')[1].split(';')[0], cookie.split('datr=')[1].split(';')[0], cookie.split('c_user=')[1].split(';')[0],cookie.split('wd=')[1].split(';')[0], cookie.split('xs=')[1].split(';')[0],cookie.split('fr=')[1].split(';')[0],id_page)
		bucket_id = story_url.split('facebook.com/stories/')[1].split('/')[0]
		story_id = story_url.split(f'{bucket_id}/')[1].split('/')[0]
		headers = {
			'authority': 'www.facebook.com',
			'accept': '*/*',
			'accept-language': 'vi,en;q=0.9,vi-VN;q=0.8,fr-FR;q=0.7,fr;q=0.6,en-US;q=0.5',
			'cookie': ck_pro5,
			'origin': 'https://www.facebook.com',
			'referer': 'https://www.facebook.com',
			'sec-ch-prefers-color-scheme': 'dark',
			'sec-ch-ua': '"Google Chrome";v="107", "Chromium";v="107", "Not=A?Brand";v="24"',
			'sec-ch-ua-mobile': '?0',
			'sec-ch-ua-platform': '"Windows"',
			'sec-fetch-dest': 'empty',
			'sec-fetch-mode': 'cors',
			'sec-fetch-site': 'same-origin',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36',
			'x-fb-friendly-name': 'storiesUpdateSeenStateMutation',
		}
		data = {
			'av': id_page,
			'fb_dtsg': self.fb_dtsg,
			'jazoest': self.jazoest,
			'fb_api_caller_class': 'RelayModern',
			'fb_api_req_friendly_name': 'storiesUpdateSeenStateMutation',
			'variables': '{"input":{"bucket_id":"'+bucket_id+'","story_id":"'+story_id+'","actor_id":"'+id_page+'","client_mutation_id":"1"},"scale":1}',
			'server_timestamps': 'true',
			'doc_id': '5127393270671537',
		}
		try:
			xem = requests.post('https://www.facebook.com/api/graphql/', headers=headers, data=data).json()
			check = xem['data']['direct_message_thread_update_seen_state']['story']['story_card_seen_state']['is_seen_by_viewer']
			print(Colorate.Horizontal(Colors.green_to_white, f'[Successfully] | {bucket_id} | VIEW | {id_page} | {name} |'))
		except:
			print(Colorate.Horizontal(Colors.green_to_white, f'[Fails] | {bucket_id} | VIEW | {id_page} | {name} |'))
			
	def reaction_str(self, story_url, type, id_page, name):
		cookie = self.cookie
		ck_pro5 = 'sb={}; datr={}; c_user={}; wd={}; xs={}; fr={}; i_user={};'.format(cookie.split('sb=')[1].split(';')[0], cookie.split('datr=')[1].split(';')[0], cookie.split('c_user=')[1].split(';')[0],cookie.split('wd=')[1].split(';')[0], cookie.split('xs=')[1].split(';')[0],cookie.split('fr=')[1].split(';')[0],id_page)
		bucket_id = story_url.split('facebook.com/stories/')[1].split('/')[0]
		story_id = story_url.split(f'{bucket_id}/')[1].split('/')[0]
		if type == '1': cx = '👍'
		elif type == '2': cx = '❤️'
		elif type == '3': cx = '😆'
		elif type == '4': cx = '🤗'
		elif type == '5': cx = '😮'
		elif type == '6': cx = '😢'
		elif type == '7': cx = '😡'
		else: cx = '☠️'
		headers={
			'Host':'www.facebook.com',
			'sec-ch-ua':'"Chromium";v="107", "Not=A?Brand";v="24"',
			'sec-ch-ua-mobile':'?0',
			'user-agent':'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36',
			'viewport-width':'980',
			'content-type':'application/x-www-form-urlencoded',
			'x-fb-lsd':'B3F7Ig_Qv4qJimRIo4q4eT',
			'x-fb-friendly-name':'useStoriesSendReplyMutation',
			'sec-ch-prefers-color-scheme':'light',
			'sec-ch-ua-platform':'"Linux"',
			'accept':'*/*',
			'origin':'https://www.facebook.com',
			'sec-fetch-site':'same-origin',
			'sec-fetch-mode':'cors',
			'sec-fetch-dest':'empty',
			'referer':story_url,
			'accept-language':'vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5',
			'cookie':ck_pro5
		}
		data={
			'av': id_page,
			'fb_dtsg': self.fb_dtsg,
			'jazoest': self.jazoest,
			'fb_api_caller_class':'RelayModern',
			'fb_api_req_friendly_name':'useStoriesSendReplyMutation',
			'variables':'{"input":{"attribution_id_v2":"StoriesCometSuspenseRoot.react,comet.stories.viewer,via_cold_start,1669267579816,844710,,","lightweight_reaction_actions":{"offsets":[0],"reaction":"'+cx+'"},"message":"'+cx+'","story_id":"'+story_id+'","story_reply_type":"LIGHT_WEIGHT","actor_id":"'+id_page+'","client_mutation_id":"1"}}',
			'server_timestamps':'true',
			'doc_id':'4826141330837571',
		}
		try:
			reac=requests.post('https://www.facebook.com/api/graphql/', headers=headers, data=data).json()
			check = reac['data']['direct_message_reply']['story']['story_card_info']['story_card_reactions']['edges'][0]['node']['messaging_actions']['count']
			print(Colorate.Horizontal(Colors.green_to_white, f'[Successfully] | | {bucket_id} | {cx} | {name} | {id_page} | {check}'))
		except:
			print(Colorate.Horizontal(Colors.green_to_white, f'[Fails] | {name} | {id_page}'))

while True:
	while True:
		os.system('cls')
		cookie = input((Colorate.Horizontal(Colors.green_to_white, 'Enter Input Cookie: ')))
		fb = Facebook(cookie)
		a=fb.get_thongtin()
		if a == 0:
			continue
		data_pro5 = fb.get_pro5()
		if data_pro5 == 0:
			continue
		else:
			break
	while True:
		story_url = input((Colorate.Horizontal(Colors.green_to_white, 'Enter Link Story: ')))
		try:
			bucket_id = story_url.split('facebook.com/stories/')[1].split('/')[0]
			story_id = story_url.split(f'{bucket_id}/')[1].split('/')[0]

			break
		except:
			print(Colorate.Horizontal(Colors.green_to_white, 'Link Story Error!'))

	print(Colorate.Horizontal(Colors.green_to_white, """
Enter Input [1] Buff View Story
Enter Input [2] Buff Reaction Story
"""))
	chon_loai=input('\033[1;32mEnter Input: \033[1;37m')
	if chon_loai == '1':
		for x in data_pro5:
			id_page=x['profile']['id']
			name=x['profile']['name']
			threading.Thread(target=fb.View,args=(story_url,id_page,name)).start()

	if chon_loai == '2':
		print(Colorate.Horizontal(Colors.green_to_white, """
Enter Input [1] LIKE
Enter Input [2] LOVE
Enter Input [3] HAHA
Enter Input [4] CARE
Enter Input [5] WOW
Enter Input [6] SAD
Enter Input [7] ANGRY
"""))
		loai = input((Colorate.Horizontal(Colors.green_to_white, 'Enter Input ==>: ')))
		soluong = int(input()(Colorate.Horizontal(Colors.green_to_white, 'Enter Input Number Reaction: ')))
		while (dem <= soluong):
			for x in data_pro5:
				id_page=x['profile']['id']
				name=x['profile']['name']
				threading.Thread(target=fb.reaction_str,args=(story_url, random.choice(loai), id_page, name)).start()
				dem+=1
