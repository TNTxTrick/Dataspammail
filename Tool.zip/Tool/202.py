
ngay = str(__import__('time').strftime("%d"))
thang = str(__import__('time').strftime("%m"))
nam = str(__import__('time').strftime("%Y"))
class Key:
    def keyfree():
        return __import__('hashlib').md5(f"NgTuw-{ngay}{thang}{nam}{ip}{pyver}".encode()).hexdigest()
    def keyvip():
        return ["keyvipbytoolngtuw", "ngtuwdz"]
if __import__('os').path.exists("NgTuwKey.json"):
    code = __import__('json').loads(open("NgTuwKey.json", "r").read())
    inp = code['key']
    mode = code['mode']
    key = Key.keyfree() if mode == 1 else Key.keyvip()
    if inp in key:
        pass
    else:
        __import__('sys').exit()
else:
    __import__('sys').exit()


import os
import aiohttp
import asyncio
import datetime
import time
from pystyle import Colors, Colorate

def read_lines_from_file(filename):
    try:
        with open(filename, 'r') as f:
            lines = f.readlines()
            return [line.strip() for line in lines if line.strip()]
    except FileNotFoundError:
        print(Colorate.Horizontal(Colors.green_to_white, f"File {filename} không tồn tại."))
        return []

success = []
list_token = []

async def getid(session, link):
    async with session.post('https://id.traodoisub.com/api.php', data={"link": link}) as response:
        rq = await response.json()
        if 'success' in rq:
            return rq["id"]
        else:
            exit(Colorate.Horizontal(Colors.green_to_white, "Wrong post link!!! Please re-enter"))

async def get_token(session, token, cookie):
    params = {'access_token': token}
    headers = {
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'cookie': cookie,
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36'
    }
    async with session.get('https://graph.facebook.com/me/accounts', params=params, headers=headers) as r:
        rq = await r.json()
        if 'data' in rq:
            return rq
        else:
            exit(Colorate.Horizontal(Colors.green_to_white, "Wrong Token Or Cookie! Please re-enter"))

async def shareao(session, tk, ck, post):
    while True:
        now = datetime.datetime.now()
        current_time = now.strftime("%H:%M:%S")
        headers = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'cookie': ck,
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36'
        }
        async with session.get(f'https://graph.facebook.com/me/feed?method=POST&link=https://m.facebook.com/{post}&published=0&access_token={tk}', headers=headers) as response:
            json = await response.json()
            if 'id' in json:
                print(Colorate.Horizontal(Colors.green_to_white, f"Success Share: [{len(success)}] | Time: [{current_time}] | ID: [{json['id']}]"))
                success.append(json['id'])
            else:
                print(Colorate.Horizontal(Colors.green_to_white, f"Fails: [{len(success)}] | Time: [{current_time}]"))
                break

async def main(link, cookies_file, tokens_file):
    async with aiohttp.ClientSession() as session:
        post = await getid(session, link)
        cookies = read_lines_from_file(cookies_file)
        if not cookies:
            exit(Colorate.Horizontal(Colors.green_to_white, "Did you add cookies or are the cookies dead ?"))
        tokens = read_lines_from_file(tokens_file)
        if not tokens:
            exit(Colorate.Horizontal(Colors.green_to_white, "Did you add token or are the token dead ?"))
        total_tokens = 0
        for token in tokens:
            token_data = await get_token(session, token, cookies[0])
            if 'data' in token_data:
                list_token.extend([t["access_token"] for t in token_data["data"]])
                total_tokens += len(token_data["data"])
                print(Colorate.Horizontal(Colors.green_to_white, f"Token Page: {len(token_data['data'])}"))
        print(Colorate.Horizontal(Colors.green_to_white, f"Success Numbers Total Tokens: {total_tokens}"))
        await asyncio.gather(*[shareao(session, tk, cookies[0], post) for tk in list_token])
        print(Colorate.Horizontal(Colors.green_to_white, f"Success Total Numbers Share: {len(success)}"))

if __name__ == "__main__":
    link = input(Colorate.Horizontal(Colors.green_to_white, "Enter Link Post: "))
    cookies_file = input(Colorate.Horizontal(Colors.green_to_white, "Enter Input File Cookie: "))
    tokens_file = input(Colorate.Horizontal(Colors.green_to_white, "Enter Input File Token: "))
    asyncio.run(main(link, cookies_file, tokens_file))
