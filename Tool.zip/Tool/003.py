from time import sleep
import re
import requests
import colorama
from concurrent.futures import ThreadPoolExecutor
colorama.init()

def nghigiailao(o):
    while o > 0:
        for color in [99, 226, 207]:
            print(f"\033[38;5;{color}m[T-TOOL][Vui Lòng Chờ][{o} Giây]", end='\r')
            sleep(1 / 5)
        o -= 1

class Machine:
    def __init__(self):
        self.session = []
        self.delay = 0
        self.url = None
        self.dict_buff = {'1': 'like', '2': 'love', '3': 'care', '4': 'haha', '5': 'wow', '6': 'sad', '7': 'angry'}
        self.list_select = []
        self.headers_buff = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-language': 'vi-VN,vi;q=0.9,zh-CN;q=0.8,zh;q=0.7,en-AU;q=0.6,en;q=0.5,fr-FR;q=0.4,fr;q=0.3,en-US;q=0.2',
            'cache-control': 'max-age=0',
            'content-type': 'application/x-www-form-urlencoded',
            'sec-ch-ua': '"Not:A-Brand";v="99", "Chromium";v="112"',
            'sec-ch-ua-mobile': '?1',
            'sec-ch-ua-platform': '"Android"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-user': '?1',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Linux; Android 12; SM-A037F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Mobile Safari/537.36',
        }
    
    def login(self, cookie):
        session = requests.Session()
        a = session.get('https://machineliker.net/login')
        headers = {
            'accept': 'application/json, text/plain, */*',
            'accept-language': 'vi-VN,vi;q=0.9,zh-CN;q=0.8,zh;q=0.7,en-AU;q=0.6,en;q=0.5,fr-FR;q=0.4,fr;q=0.3,en-US;q=0.2',
            'content-type': 'application/x-www-form-urlencoded',
            'sec-ch-ua': '"Not:A-Brand";v="99", "Chromium";v="112"',
            'sec-ch-ua-mobile': '?1',
            'sec-ch-ua-platform': '"Android"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-origin',
            'user-agent': 'Mozilla/5.0 (Linux; Android 12; SM-A037F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Mobile Safari/537.36',
            'x-requested-with': 'XMLHttpRequest',
            'x-xsrf-token': session.cookies.get('XSRF-TOKEN').replace('%3D', '='),
        }
        data = {'session': cookie}
        response = session.post('https://machineliker.net/login', headers=headers, data=data).json()
        if response['success']:
            name = response['user']['name']
            id_ = response['user']['id']
            print(f"\033[1;32mLogin Thành Công: {id_} | {name}\033[0m")
            return session
        else:
            print(f"\033[1;31mLogin Thất Bại! Kiểm Tra Lại Cookie Facebook\033[0m")
            return None

    def buff(self, session):
        try:
            get_token = session.get('https://machineliker.net/auto-reactions').text
            token = get_token.split('name="_token" value="')[1].split('"')[0]
            hash_ = get_token.split('name="hash" value="')[1].split('"')[0]
            data_buff = {
                'url': self.url,
                'limit': '20',
                'reactions[]': self.list_select,
                '_token': token,
                'hash': hash_
            }
            response = session.post('https://machineliker.net/auto-reactions', headers=self.headers_buff, data=data_buff).text
            if '><strong>Error!</strong>' in response or "You're currently under cooldown periods, please try again after" in response:
                count = re.findall(r'please try again after (\d+) minutes.</p>', response)[0]
                second = int(count) * 60
                print(f"\033[1;33mĐang cooldown, vui lòng đợi {second}s nữa.\033[0m")
                self.delay = second
            elif 'Order Submitted' in response:
                print(f"\033[1;32mTăng Thành Công +20 Cảm Xúc\033[0m")
                self.delay = 400
            else:
                print(f"\033[1;31mLỗi: Vui lòng thử lại sau 20 phút.\033[0m")
        except Exception as e:
            print(f"\033[1;31mĐã xảy ra lỗi trong quá trình buff: {e}\033[0m")

    def main(self):
        cookies = input(" \033[1;37;40m➤ \033[1;31;40m[\033[1;33;40m«\033[1;37;40m/\033[1;33;40m»\033[1;31;40m] \033[1;37;40m> \033[1;32mNhập Cookie Facebook: \033[1;35m")
        session = self.login(cookies)
        if session:
            self.url = input(" \033[1;37;40m➤ \033[1;31;40m[\033[1;33;40m«\033[1;37;40m/\033[1;33;40m»\033[1;31;40m] \033[1;37;40m> \033[1;32mNhập Link Bài Viết Cần Buff: \033[1;35m")
            print(' \033[1;37;40m➤ \033[1;31;40m[\033[1;33;40m«\033[1;37;40m/\033[1;33;40m»\033[1;31;40m] \033[1;37;40m> ', self.dict_buff)
            select = input(" \033[1;37;40m➤ \033[1;31;40m[\033[1;33;40m«\033[1;37;40m/\033[1;33;40m»\033[1;31;40m] \033[1;37;40m> \033[1;32mChọn Cảm Xúc: \033[1;35m")
            self.list_select = [self.dict_buff[x] for x in select]
            with ThreadPoolExecutor(max_workers=5) as executor:
                while True:
                    executor.map(self.buff, [session] * 5)
                    nghigiailao(self.delay)

if __name__ == "__main__":
    Machine().main()