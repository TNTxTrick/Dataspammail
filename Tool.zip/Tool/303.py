ngay = str(__import__('time').strftime("%d"))
thang = str(__import__('time').strftime("%m"))
nam = str(__import__('time').strftime("%Y"))
class Key:
    def keyfree():
        return __import__('hashlib').md5(f"NgTuw-{ngay}{thang}{nam}{ip}{pyver}".encode()).hexdigest()
    def keyvip():
        return ["keyvipbytoolngtuw", "ngtuwdz"]
if __import__('os').path.exists("NgTuwKey.json"):
    code = __import__('json').loads(open("NgTuwKey.json", "r").read())
    inp = code['key']
    mode = code['mode']
    key = Key.keyfree() if mode == 1 else Key.keyvip()
    if inp in key:
        pass
    else:
        __import__('sys').exit()
else:
    __import__('sys').exit()


import random
import requests
import time
import os

colors = {
    "trang": "\033[1;37m\033[1m",
    "xanh_la": "\033[1;32m\033[1m",
    "xanh_duong": "\033[1;34m\033[1m",
    "xanh_nhat": '\033[1m\033[38;5;51m',
    "do": "\033[1;31m\033[1m",
    "xam": '\033[1;30m\033[1m',
    "vang": "\033[1;33m\033[1m",
    "tim": "\033[1;35m\033[1m",
    "dac_biet": "\033[32;5;245m\033[1m\033[38;5;39m",
}
random_color = random.choice(list(colors.values()))

def idelay(count):
    stages = ["[.....]", "[•....]", "[••...]", "[•••..]", "[••••.]", "[•••••]"]
    while count > 0:
        for stage in stages:
            print(
                f"{colors['trang']}[{colors['xanh_nhat']}T-TOOL{colors['trang']}] "
                f"\033[1;33mV\033[1;34mu\033[1;35mi \033[1;32mL\033[1;33mò\033[1;34mn\033[1;35mg \033[1;36mC\033[1;33mh\033[1;34mờ "
                f"{colors['trang']}{stage} [{count}]   ",
                end="\r",
            )
            time.sleep(1 / 6)
        count -= 1
    print()

def get_input():
    id_canspam = input(f' \033[1;37;40m➤ \033[1;31;40m[\033[1;33;40m«\033[1;37;40m/\033[1;33;40m»\033[1;31;40m] \033[1;37;40m> {colors["xanh_nhat"]}Nhập ID Người Cần Spam Hoặc ID Box:{colors["vang"]} ')
    while True:
        cookie = input(f' \033[1;37;40m➤ \033[1;31;40m[\033[1;33;40m«\033[1;37;40m/\033[1;33;40m»\033[1;31;40m] \033[1;37;40m> {colors["xanh_nhat"]}Nhập Cookie:{colors["vang"]} ')
        try:
            url = f"https://mbasic.facebook.com/privacy/touch/block/confirm/?bid={id_canspam}&ret_cancel&source=profile"
            headers = {
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                'accept-language': 'vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5',
                'cookie': cookie,
                'sec-fetch-dest': 'document',
                'sec-fetch-mode': 'navigate',
                'sec-fetch-site': 'same-origin',
                'sec-fetch-user': '?1',
                'upgrade-insecure-requests': '1',
            }
            response = requests.get(url, headers=headers).text
            fb_dtsg = response.split('<input type="hidden" name="fb_dtsg" value="')[1].split('" autocomplete="off" />')[0]
            jazoest = response.split('<input type="hidden" name="jazoest" value="')[1].split('" autocomplete="off" />')[0]
            clear()
            return cookie, fb_dtsg, jazoest
        except IndexError:
            print(f'{colors["do"]}Cookie sai!!')

CAU_CHUI = input(f" \033[1;37;40m➤ \033[1;31;40m[\033[1;33;40m«\033[1;37;40m/\033[1;33;40m»\033[1;31;40m] \033[1;37;40m> {colors['xanh_nhat']}Nhập Nội Dung {colors['trang']}({colors['xanh_duong']}Cách Nhau Bằng Dấu Phẩy{colors['trang']}):{colors['vang']} ").split(",")

def main():
    cookie, fb_dtsg, jazoest = get_input()
    print(f'{colors["xanh_duong"]}Đang xử lý với cookie và dữ liệu nhận được...')
    params = {"icm": '1'}
    headers = {
        "Host": "mbasic.facebook.com",
        "content-type": "application/x-www-form-urlencoded",
        "user-agent": "Mozilla/5.0 (Linux; Android 8.1.0; Redmi 5A Build/OPM1.171019.026) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.5735.130 Mobile Safari/537.36",
        "cookie": cookie,
    }
    while True:
        cau_chui = random.choice(CAU_CHUI)
        print(f"[ \033[1;37;40m➤ \033[1;31;40m[\033[1;33;40mT-TOOL\033[1;31;40m] \033[1;37;40m> {colors['xanh_la']} Nội Dung {colors['trang']}( colors['xanh_duong']{cau_chui} colors['trang'])")
        time.sleep(1)
if __name__ == "__main__":
    main()