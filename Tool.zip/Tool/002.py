
ngay = str(__import__('time').strftime("%d"))
thang = str(__import__('time').strftime("%m"))
nam = str(__import__('time').strftime("%Y"))
class Key:
    def keyfree():
        return __import__('hashlib').md5(f"NgTuw-{ngay}{thang}{nam}{ip}{pyver}".encode()).hexdigest()
    def keyvip():
        return ["keyvipbytoolngtuw", "ngtuwdz"]
if __import__('os').path.exists("NgTuwKey.json"):
    code = __import__('json').loads(open("NgTuwKey.json", "r").read())
    inp = code['key']
    mode = code['mode']
    key = Key.keyfree() if mode == 1 else Key.keyvip()
    if inp in key:
        pass
    else:
        __import__('sys').exit()
else:
    __import__('sys').exit()


import requests
import json
import random
import string

def jsonResults(dataJson, statusLogin, listExportCookies=None):
     if statusLogin == 1:
          return {
               "success": {
                    "setCookies": "".join(listExportCookies),
                    "accessTokenFB": dataJson["access_token"],
                    "cookiesKey-ValueList": dataJson["session_cookies"]
               }
          }
     else:
          return {
               "error": {
                    "title": dataJson["error"]["error_user_title"],
                    "description": dataJson["error"]["error_user_msg"],
                    "error_subcode": dataJson["error"]["error_subcode"],
                    "error_code": dataJson["error"]["code"],
                    "fbtrace_id": dataJson["error"]["fbtrace_id"],
               }
          }
               
def randStr(length):
    return "".join(random.choices(string.ascii_lowercase + string.digits, k=length))
         
def GetToken2FA(key2Fa):
     try:
          twoFARequests = json.loads(requests.get("https://2fa.live/tok/" + key2Fa.replace(" ","")).text)
          return twoFARequests["token"] 
     except:
          return random.randint(100000, 999999)

class loginFB:

     def __init__(self, username, password, AuthenticationGoogleCode=None):
          self.deviceID = self.adID = self.secureFamilyDeviceID = f"{randStr(8)}-{randStr(4)}-{randStr(4)}-{randStr(4)}-{randStr(12)}"
          self.manchineID = randStr(24)
          self.usernameFacebook = username
          self.passwordFacebook = password
          self.twoTokenAccess = AuthenticationGoogleCode 
     def main(self):
          headers = {
               "Host": "b-graph.facebook.com",
               "Content-Type": "application/x-www-form-urlencoded",
               "X-Fb-Connection-Type": "unknown",
               "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 7.1.2; SM-G988N Build/NRD90M) [FBAN/FB4A;FBAV/340.0.0.27.113;FBPN/com.facebook.katana;FBLC/vi_VN;FBBV/324485361;FBCR/Viettel Mobile;FBMF/samsung;FBBD/samsung;FBDV/SM-G988N;FBSV/7.1.2;FBCA/x86:armeabi-v7a;FBDM/{density=1.0,width=540,height=960};FB_FW/1;FBRV/0;]",
               "X-Fb-Connection-Quality": "EXCELLENT",
               "Authorization": "OAuth null",
               "X-Fb-Friendly-Name": "authenticate",
               "Accept-Encoding": "gzip, deflate",
               "X-Fb-Server-Cluster": "True"
          }
          
          dataForm = {
               "adid": self.adID,
               "format": "json",
               "device_id": self.deviceID,
               "email": self.usernameFacebook,
               "password": self.passwordFacebook,
               "generate_analytics_claim": "1",
               "community_id": "",
               "cpl": "true",
               "try_num": "1",
               "family_device_id": self.deviceID,
               "secure_family_device_id": self.secureFamilyDeviceID,
               "credentials_type": "password",
               "fb4a_shared_phone_cpl_experiment": "fb4a_shared_phone_nonce_cpl_at_risk_v3",
               "fb4a_shared_phone_cpl_group": "enable_v3_at_risk",
               "enroll_misauth": "false",
               "generate_session_cookies": "1",
               "error_detail_type": "button_with_disabled",
               "source": "login",
               "machine_id": self.manchineID,
               "jazoest": "22421",
               "meta_inf_fbmeta": "",
               "advertiser_id": self.adID,
               "encrypted_msisdn": "",
               "currently_logged_in_userid": "0",
               "locale": "vi_VN",
               "client_country_code": "VN",
               "fb_api_req_friendly_name": "authenticate",
               "fb_api_caller_class": "Fb4aAuthHandler",
               "api_key": "882a8490361da98702bf97a021ddc14d",
               "access_token": "350685531728|62f8ce9f74b12f84c123cc23437a4a32"
          }
         
          dataJson = json.loads(requests.post("https://b-graph.facebook.com/auth/login", data=dataForm, headers=headers).text)
          if dataJson.get("error") is not None:
               if dataJson["error"]["error_subcode"] == 1348162:
                    Get2FA = GetToken2FA(self.twoTokenAccess)
                    dataForm2Fa = dataForm.copy()
                    dataForm2Fa.update({
                         "password": Get2FA,
                         "credentials_type": "two_factor",
                         "twofactor_code": Get2FA,
                         "userid": dataJson["error"]["error_data"]["uid"],
                         "first_factor": dataJson["error"]["error_data"]["login_first_factor"]
                    })
                    pass2Fa = json.loads(requests.post("https://b-graph.facebook.com/auth/login", data=dataForm2Fa, headers=headers).text)
                    if pass2Fa.get("error") is None:
                         listExportCookies = [f"{cookie['name']}={cookie['value']}; " for cookie in pass2Fa.get("session_cookies", [])]
                         return jsonResults(pass2Fa, 1, listExportCookies)
                    else:
                         return jsonResults(pass2Fa, 0)
               else:
                    return jsonResults(dataJson, 0)
          else:
               listExportCookies = [f"{cookie['name']}={cookie['value']}; " for cookie in dataJson.get("session_cookies", [])]
               return jsonResults(dataJson, 1, listExportCookies)

chars = f" \033[1;37;40m➤ \033[1;31;40m[\033[1;33;40m«\033[1;37;40m/\033[1;33;40m»\033[1;31;40m] \033[1;37;40m>"
username = input(f"{chars} \033[1;36;40mNhập Gmail Hoặc Số Điện Thoại: \033[1;37;40m")
password = input(f"{chars} \033[1;36;40mNhập Mật Khẩu: \033[1;37;40m")
twoFactorCode = input(f"{chars} \033[1;36;40mNhập Mã 2FA (Nếu Không Có Thì Enter): \033[1;37;40m")

result = loginFB(username, password, twoFactorCode).main()
if "success" in result:
    print("\033[1;36;40m[SUCCESS] Login successful!")
    print("\033[1;36;40mAccess Token:\033[1;37;40m", result["success"]["accessTokenFB"])
    print("\033[1;36;40mCookies:\033[1;37;40m", result["success"]["cookiesKey-ValueList"])
else:
    print("\033[1;36;40mLogin failed!")
    print("\033[1;36;40mError:\033[1;31;40m", result["error"])